Any harm done is liable to user and downloader of the cheat not distributer
Before using make sure Windows is disable due too false positives